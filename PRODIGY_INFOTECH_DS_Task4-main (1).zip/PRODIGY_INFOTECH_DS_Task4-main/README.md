# PRODIGY_INFOTECH_DS_Task4
This project performs a sentiment analysis on Twitter data.

The code uses a dataset of tweets to analyze the sentiment distribution across different entities and specifically for Microsoft.

The analysis includes handling missing data, removing duplicates, and visualizing the sentiment distribution.
